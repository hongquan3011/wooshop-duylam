package poly.edu.repository;



import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import poly.edu.entity.Category;
import poly.edu.entity.Product; 
@Repository
public interface ProductRepository extends JpaRepository<Product,Integer>{
	 List<Product> findByType(Boolean n );
	 List<Product> findByNameContainingOrCategory(String name,Category category);
	 @Query("SELECT o FROM Product o WHERE o.name LIKE ?1")
		Page<Product> findByKeywords(String string, Pageable pageable);
}
